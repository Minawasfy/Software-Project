<html>

<head>
<title>
Fun & Learn: Contact Us
</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> <!--fb icon-->
</head>

<body>

<div class = "footer">

	<strong>
		<h1 id="cntctU">Contact Us:</h1>
	</strong> 
	<div id="cntct1">
		Address:El Shatr(7), Zahraa El Maadi
		<br>Contact:01067088943
	</div>
	<div id="cntct1">
		Address:Al Me3rag, Maadi
		<br>Contact:01004011048
	</div>
	<div id="cntct1">
		Fun & Learn Preschool <a href="https://www.facebook.com/funandlearnnursery/" class="fa fa-facebook"></a>
	</div>
</div>

</body>
<style type="text/css">
	#cntctU{
		text-align: center;
		font-size: 15px;
	}
	#cntct1{
		float: left;
		width: 33.33%;
	}
	.fa {
	    padding: 15px;
	    font-size: 10px;
	    width: 10px;
	    text-align: center;
	    text-decoration: none;
	    border-radius: 25%;
	}
	.fa:hover {
	    opacity: 0.7;
	}

	.fa-facebook {
	  background: #3B5998;
	  color: white;
	}
</style>


</html>
