<html>

<head>

<title>

Fun & Learn

</title>
<style type="text/css">
		header{
			height: 100;
		}
		header #logo{
			margin-top: 20px;
			margin-left: 20px;
			width: 120px;
			height: 60px;
		}
	</style>
<img src="logo.png" id="logo">

<h1 align="left"> <p><u>Preliminary Teacher Application:</u></p> </h1>
</head>

<body>


<div class = "teacher1">


<form>

Full name:<br>
<input type="text" name="Fname" required><br>
Date of birth:<br>
<input type="date" name="tdob" required><br>
Nationality age:<br>
<input type="number" name="nat" required><br>
Home Address:<br>
<input type="text" name="address1" required><br>
Telephone number:<br>
<input type="text" name="Tel" maxlength="8" required><br>
Mobile number 1:<br>
<input type="text" name="number1" maxlength="11" required><br>
Mobile number 2:<br>
<input type="text" name="number1" maxlength="11"><br>
Marital Status:<br>
<input type="radio" name="status" value="Single" checked>Single<br>
<input type="radio" name="status" value="Married">Married<br>
<input type="radio" name="status" value="Divorced">Divorced<br>
<input type="radio" name="status" value="Widowed">Widowed<br>
Academic Qualifications with Dates:<br>
Qualification 1:
<textarea rows="1" cols="50"></textarea>
<input type="Date" name="q1"><br>
Qualification 2:
<textarea rows="1" cols="50"></textarea>
<input type="Date" name="q2"><br>
Qualification 3:
<textarea rows="1" cols="50"></textarea>
<input type="Date" name="q3"><br>
Qualification 4:
<textarea rows="1" cols="50"></textarea>
<input type="Date" name="q4"><br>
Qualification 5:
<textarea rows="1" cols="50"></textarea>
<input type="Date" name="q5"><br>
<hr>
Professional Qualifications with Dates:<br>
Qualification 1:
<textarea rows="1" cols="50"></textarea>
<input type="Date" name="q11"><br>
Qualification 2:
<textarea rows="1" cols="50"></textarea>
<input type="Date" name="q22"><br>
Qualification 3:
<textarea rows="1" cols="50"></textarea>
<input type="Date" name="q33"><br>
Qualification 4:
<textarea rows="1" cols="50"></textarea>
<input type="Date" name="q44"><br>
Qualification 5:
<textarea rows="1" cols="50"></textarea>
<input type="Date" name="q55"><br>
<hr>

Present Employer's Name:<br>
<input type="text" name="Emname" required><br>
Present Employer's Address:<br>
<input type="text" name="num123" ><br>
Present Employer's phone number:<br>
<input type="text" name="Emnum" maxlength="11" required><br>
<hr>

Current or Last Salary:<br>
<input type="number" name="salary" min="1" max ="10000" required><br>
Required Salary:<br>
<input type="number" name="salary1" min="1" max ="10000" required><br>

Have you been interviewed recently at other nurseries? if yes, please mention names:<br>
<input type="text" name="other1"><br>

In your point of view, how do you see an ideal nursery regarding its academic side?
<textarea rows="1" cols="50"></textarea>

<br>

<hr><input type="submit" value="Submit Form">
<input type="reset"  value="Reset Form">

</html>
