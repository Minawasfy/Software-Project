<html>

<head>
<title>
Fun & Learn: About Us

</title>
<img src="logo.png" id="logo">
<h1 id="hdr">About Us</h1>

</head>

<body>

<div class = "mission">

<strong><h2>Mission :</h2></strong>
Many parents are concerned when their children are not practicing letters 
and numbers, they feel that completing paper and pencil exercises will most 
effectively prepare their children for elementary school. To change this common idea
in our society we are working in our nursery hand in hand with parents in order to 
enrich your child's physical and mental development through our "Fun and Learn" strategy,
where the child can enjoy learning through playing by using different activities.
Our concept is aiming to increase the child's self confidence, encourage him to think
widely and independently & work using his/her  own hands to prepare him to do pencil & paper
work, a step that should come at some stage of preschool education without stressing over it.
</div>
<br>
<div class = "vision">
<h2>Vision :</h2>
 Our program is based on the "Fun & Learn" strategy where all acitivities kids experience at the nursery are aiming to teach new skills they need, even fun acitvities:<br>
 <br>
<strong>Fun:</strong> quality time, where children can enjoy being creative, being part of a team, solving problems, trying to win, accepting loss, share, work on motor skills,and act in live preformances.<br>
<br>
<strong>Learn:</strong> New skills & how to face future life challenges through our academic program which is very well prepared to help children enhancing their language skills, imagination, gross/fine motor skills, cognitive/thinking skills, social skills,and mental principles. <br>



</div>

<br>

	<div id="footer">
		<object type="text/html" data="Contactus.php" id="ftr"></object>
	</div>

	<style type="text/css">
		header{
			height: 100;
		}
		header #logo{
			margin-top: 20px;
			margin-left: 20px;
			width: 120px;
			height: 60px;
		}
		#hdr{
			position: relative;
			top: -60px;
			left: 300px;
		}
		#footer{
			position: absolute;
			bottom: -150;
			left: 0;
			right: 0;
			width: 100%;
			height: 100px;
		    background-color: #ccccb3;
		}
		#ftr{
			width: 100%;
		}
	</style>

</html>
